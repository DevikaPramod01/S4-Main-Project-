from flask import Flask, redirect, render_template, url_for, request
import re
import math
import csv

from nltk import NaiveBayesClassifier as nbc
from nltk.tokenize import word_tokenize
from itertools import chain
import urllib.request
import time

from os import walk

import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from keras.models import load_model
###############################
from os import walk

import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder

from tensorflow.keras.optimizers import SGD, Adam, Adadelta
from tensorflow.keras.layers import Conv1D, Dense, MaxPooling1D, Flatten, Dropout
from tensorflow.keras.models import Sequential
from tensorflow.keras.regularizers import l2, l1

from sklearn.metrics import confusion_matrix
import tensorflow.keras as keras
import datetime
import argparse
import os
###############################



app = Flask(__name__)

@app.route('/success/<name>')
def success(name):
   #return name
   return render_template('result.html', prediction=name)

urlp=""

@app.route('/login',methods = ['POST', 'GET'])
def login():
   if request.method == 'POST':
      #ans = request.form['ans'
      #key = request.form['key']
      sequence=request.form['sequence']
      print(sequence)
      
      integer_encoder = LabelEncoder()
      one_hot_encoder = OneHotEncoder()
      input_features = []
      hupfeature=[]
      
      integer_encoded = integer_encoder.fit_transform(list(sequence))
      integer_encoded = np.array(integer_encoded).reshape(-1, 1)
      one_hot_encoded = one_hot_encoder.fit_transform(integer_encoded)
      input_features.append(one_hot_encoded.toarray())
      input_features = np.stack(input_features)
      input_features=input_features
      model = load_model("trojancnn.h5")
      #print(model.summary())
      #print("HUPA")
      prediction = model.predict_on_batch(np.stack(input_features))
      hupfeature=prediction[0]
      label=''
      if hupfeature[0]>hupfeature[1]:
        label='Non Trojan'
      else:
        label='Trojan'
      #percentage=calcsimilarity()
      return redirect(url_for('success',name = label))
   else:
      user = request.args.get('nm')
      return redirect(url_for('success',name = user))



def calcsimilarity():
    

    writer.writerows(all)
    csvoutput.close()
   
    match_percentage = 0
    

    
    return rownum

if __name__ == '__main__':
   app.run(host='0.0.0.0',port=5000,debug = True)
